package org.example.coursedesign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseDesignApplicationTests {

    @Test
    void contextLoads() {
    }

}
