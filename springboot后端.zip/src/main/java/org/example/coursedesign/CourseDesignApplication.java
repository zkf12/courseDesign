package org.example.coursedesign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseDesignApplication {

    public static void main(String[] args) {
        SpringApplication.run(CourseDesignApplication.class, args);
    }

}
