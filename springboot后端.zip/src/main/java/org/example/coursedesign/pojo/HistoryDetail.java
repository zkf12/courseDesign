package org.example.coursedesign.pojo;

import lombok.Data;

@Data
public class HistoryDetail {
    private String productName;
    private int quantity;
    private double price;
    private String shop;
}
