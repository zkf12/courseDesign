package org.example.coursedesign.pojo;

import lombok.Data;

@Data
public class tradeDto {
    private int productId;
    private int quantity;
    private double price;
}
