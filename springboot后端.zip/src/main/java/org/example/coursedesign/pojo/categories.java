package org.example.coursedesign.pojo;

import lombok.Data;

@Data
public class categories {
    private int id;
    private String category;
}
