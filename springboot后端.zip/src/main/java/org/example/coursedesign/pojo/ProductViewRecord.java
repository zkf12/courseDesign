package org.example.coursedesign.pojo;

import lombok.Data;

@Data
public class ProductViewRecord {
    private String productName;
    private Integer duration; // 单位：秒
}
