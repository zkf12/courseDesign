package org.example.coursedesign.mapper;

import org.apache.ibatis.annotations.*;
import org.example.coursedesign.pojo.HistoryDetail;
import org.example.coursedesign.pojo.PurchaseHistory;
import org.example.coursedesign.pojo.Product;

import java.util.List;

@Mapper
public interface TradeMapper {
    @Insert("insert into cart(user_id, product_id)" +
            " values(#{user_id},#{product_id})")
    void addInCart(@Param("user_id") int user_id, @Param("product_id") int product_id);

    @Select("select p.id, name, price, shop, image, description, status, category from cart join products p on p.id = cart.product_id " +
            "where user_id = #{user_id}")
    List<Product> getCart(@Param("user_id") int user_id);

    @Delete("delete from cart " +
            "where user_id = #{user_id} and product_id = #{product_id}")
    void deleteCart(@Param("user_id") int user_id, @Param("product_id") int product_id);

    @Select("select max(order_id) as order_id " +
            "from order_table;")
    int getOrderId();

    @Insert("insert into order_table(user_id,total_price) values (#{user_id},#{totalPrice})")
    void setNewOrder(@Param("user_id") int user_id, @Param("totalPrice") double totalPrice);

    @Insert("insert into order_detail (user_id, product_id, order_id, quantity) values (#{user_id}, #{product_id}, #{order_id}, #{quantity})")
    void setNewOrderDetail(@Param("user_id") int user_id, @Param("product_id") int product_id, @Param("order_id") int order_id, @Param("quantity") int quantity);

    @Select("select stock " +
            "from products " +
            "where id = #{product_id}")
    int getProductStock(@Param("product_id") int product_id);

    @Update("update products " +
            "set stock = stock - #{quantity} " +
            "where id = #{product_id}")
    void changeProductStock(@Param("product_id") int product_id, @Param("quantity") int quantity);

    @Select("<script>" +
            "SELECT distinct o.order_id, o.trade_time, o.total_price, u.username " +
            "FROM order_table o " +
            "JOIN order_detail od ON o.order_id = od.order_id " +
            "JOIN products p ON od.product_id = p.id " +
            "JOIN user u ON o.user_id = u.id " +
            "<where>" +
            "   <if test='username != null and username != \"\"'> AND u.username = #{username} </if>" +
            "   <if test=\"productName != null and productName != ''\"> AND p.name LIKE CONCAT('%', #{productName}, '%') </if>" +
            "   <if test='shop != null and shop != \"\"'> AND p.shop LIKE CONCAT('%', #{shop}, '%') </if>" +
            "</where>" +
            "LIMIT #{pageSize} OFFSET #{offset}" +
            "</script>")
    List<PurchaseHistory> getPurchaseHistory(@Param("username") String username,
                                             @Param("productName") String product_name,
                                             @Param("shop") String shop,
                                             @Param("offset") int offset,
                                             @Param("pageSize") int pageSize);
    @Select("<script>" +
            "SELECT COUNT(DISTINCT o.order_id) " +
            "FROM order_table o " +
            "JOIN order_detail od ON o.order_id = od.order_id " +
            "JOIN products p ON od.product_id = p.id " +
            "JOIN user u ON o.user_id = u.id " +
            "<where>" +
            "   <if test='username != null and username != \"\"'> AND u.username = #{username} </if>" +
            "   <if test=\"productName != null and productName != ''\"> AND p.name LIKE CONCAT('%', #{productName}, '%') </if>" +
            "   <if test='shop != null and shop != \"\"'> AND p.shop LIKE CONCAT('%', #{shop}, '%') </if>" +
            "</where>" +
            "</script>")
    int getPurchaseHistoryCount(@Param("username") String username,
                                @Param("productName") String product_name,
                                @Param("shop") String shop);

    @Select("select quantity,shop,price,products.name as productName " +
            "from order_detail " +
            "join products on order_detail.product_id = products.id " +
            "where order_id = #{orderId}")
    List<HistoryDetail> getHistoryDetail(@Param("orderId") int order_id);

}
