package org.example.coursedesign.service;

import org.example.coursedesign.pojo.*;

import java.util.List;

public interface TradeService {
    public void addInCart(int user_id,int product_id);
    public List<Product> getCart(int user_id);
    public void deleteCart(int user_id,int product_id);
    public boolean checkProductStock(List<tradeDto> list);
    public void setNewOrder(int user_id,double totalPrice,List<tradeDto> list);
    public PageInfo<PurchaseHistory> getPurchaseHistory(String username, String product_name, String shop, int pageNum, int pageSize);
    public List<HistoryDetail> getHistoryDetail(int order_id);

}
